# SOFENGG
System of Faculty Development Grants for the Office of the Vice Chancellor for Academics (VCA).
AY 2018-2019, T1
